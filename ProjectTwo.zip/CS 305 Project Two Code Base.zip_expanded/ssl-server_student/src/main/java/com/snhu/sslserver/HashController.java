package com.snhu.sslserver;

import java.util.UUID;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.RestController;

@RestController
public class HashController {

  @GetMapping("/hash")
  public String hash() {
    String name = "Benjamin Holcomb";
    String uniqueData = name + "Neo is the one." + UUID.randomUUID();

    String checksum = ChecksumUtil.sha256Hex(uniqueData);

    boolean verified = ChecksumUtil.sha256Hex(uniqueData).equalsIgnoreCase(checksum);

    return "Name: " + name +
        "\nUniqueData: " + uniqueData +
        "\nChecksum(SHA-256): " + checksum +
        "\nVerified: " + verified;
  }
}
